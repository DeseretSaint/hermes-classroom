# Answer guide — Section 1: the sear

Objective: Objective 1: sear and braise

## Reference answer
When the oil shimmers and the pan is hot

## Rubric
1. Browns every face
2. Keeps the heat steady
3. Does not crowd the pan
