# Parent guide — Section 1: the sear

Objective: Objective 1: sear and braise
Evidence target: production

Course goal: Braise short ribs at home without a pressure cooker.

## Lesson intent
Sear first, then braise.

## What the learner will do
Choose the moment that actually sears the meat.

## Worked example
The pan is only warm.
1. Wait until the oil shimmers
1. Lay the ribs away from you

## Narration script
Browning builds the flavour the braise will carry for two hours.
The ribs are dark brown on every face before they meet the liquid.
