# Section 1: the sear

## Why the sear matters
Browning builds the flavour the braise will carry for two hours.

## What good looks like
The ribs are dark brown on every face before they meet the liquid.

## Worked example
The pan is only warm.

1. Wait until the oil shimmers
1. Lay the ribs away from you

Answer: Wait for the shimmer

## What to notice
Choose the moment that actually sears the meat.

## Your turn
In one sentence, describe the moment the ribs go into the pan.

Write one sentence.
